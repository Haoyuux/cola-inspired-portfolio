
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

const CompanySection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const cansRef = useRef<HTMLDivElement>(null);
  const waveRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // Reveal animations
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
          toggleActions: 'play none none none'
        }
      });

      tl.from('.reveal-item', {
        y: 40,
        opacity: 0,
        stagger: 0.2,
        duration: 1,
        ease: 'power3.out'
      })
      .from('.can-item', {
        y: 300,
        rotate: 15,
        opacity: 0,
        stagger: 0.15,
        duration: 1.5,
        ease: 'expo.out'
      }, '-=1');

      // Wave Parallax
      gsap.to(waveRef.current, {
        y: -80,
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'bottom bottom',
          end: 'bottom top',
          scrub: true
        }
      });

      // Subtle parallax for cans
      gsap.to('.can-item', {
        y: -120,
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1
        }
      });

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      className="relative w-full min-h-screen bg-[#fdfcf8] flex flex-col md:flex-row items-center px-6 md:px-20 pt-32 pb-64 overflow-hidden z-20"
    >
      {/* Left Content */}
      <div ref={textRef} className="w-full md:w-1/2 z-10">
        <span className="reveal-item font-script text-3xl md:text-5xl text-[#0c1c3d] mb-4 block lowercase">
          something about us
        </span>
        <h2 className="reveal-item font-bebas text-7xl md:text-[9vw] leading-[0.85] text-[#0c1c3d] mb-8 distressed-navy uppercase">
          OUR COMPANY
        </h2>
        
        <p className="reveal-item max-w-lg text-[#0c1c3d]/80 text-sm md:text-base leading-relaxed mb-10 font-montserrat font-medium">
          Royal Beverage, founded in 1994, is a leading producer of refreshing and carbonated beverages, 
          committed to delivering high-quality products that meet consumer needs. With a strong focus 
          on innovation and excellent service, the company aims to expand internationally and become 
          a global leader in the private label beverage sector.
        </p>

        <button className="reveal-item px-12 py-4 bg-[#b52232] text-white font-bebas text-2xl uppercase tracking-widest hover:bg-[#8e1b27] transition-colors shadow-xl">
          ABOUT
        </button>
      </div>

      {/* Right Content - Beverage Cans */}
      <div 
        ref={cansRef} 
        className="w-full md:w-1/2 h-[600px] relative mt-20 md:mt-0 flex items-center justify-center"
      >
        <div className="can-item absolute left-[5%] md:left-[10%] bottom-0 w-[200px] md:w-[280px] -rotate-12 z-0">
          <img 
            src="https://pngimg.com/d/coca_cola_PNG18.png" 
            alt="Silver Can" 
            className="w-full h-auto filter grayscale opacity-90 drop-shadow-xl"
          />
        </div>

        <div className="can-item absolute right-[5%] md:right-[10%] bottom-0 w-[200px] md:w-[280px] rotate-12 z-0">
          <img 
            src="https://pngimg.com/d/coca_cola_PNG2.png" 
            alt="Dark Can" 
            className="w-full h-auto filter brightness-50 contrast-125 drop-shadow-xl"
          />
        </div>

        <div className="can-item absolute left-1/2 -translate-x-1/2 bottom-0 w-[220px] md:w-[320px] z-10">
          <img 
            src="https://pngimg.com/d/coca_cola_PNG20.png" 
            alt="Main Can" 
            className="w-full h-auto drop-shadow-2xl brightness-110 contrast-125 saturate-150"
          />
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-full text-center">
             <span className="font-bebas text-white/40 text-xs tracking-widest uppercase">Since 1905</span>
          </div>
        </div>
      </div>

      {/* BOTTOM TRANSITION WAVE */}
      <div 
        ref={waveRef}
        className="absolute bottom-0 left-0 w-full pointer-events-none z-0 translate-y-[2px]"
      >
        <svg 
          viewBox="0 0 1440 320" 
          className="w-full h-auto block" 
          preserveAspectRatio="none"
        >
          <path 
            fill="#b52232" 
            d="M0,192L48,197.3C96,203,192,213,288,229.3C384,245,480,267,576,250.7C672,235,768,181,864,181.3C960,181,1056,235,1152,234.7C1248,235,1344,181,1392,154.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
          ></path>
        </svg>
        {/* Solid filler to ensure zero white space gaps */}
        <div className="w-full h-32 bg-[#b52232]" />
      </div>
    </section>
  );
};

export default CompanySection;
