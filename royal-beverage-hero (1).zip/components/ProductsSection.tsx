
import React, { useState, useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';

interface Product {
  id: number;
  name: string;
  tagline: string;
  image: string;
  splash: string;
  themeColor: string;
}

const PRODUCTS: Product[] = [
  {
    id: 1,
    name: "RC COLA",
    tagline: "The Original",
    image: "https://pngimg.com/d/coca_cola_PNG20.png",
    splash: "https://static.vecteezy.com/system/resources/previews/027/292/348/original/cola-soda-splash-on-transparent-background-png.png",
    themeColor: "#b52232"
  },
  {
    id: 2,
    name: "CLASSIC RED",
    tagline: "Pure Taste",
    image: "https://pngimg.com/d/coca_cola_PNG22.png",
    splash: "https://static.vecteezy.com/system/resources/previews/027/292/348/original/cola-soda-splash-on-transparent-background-png.png",
    themeColor: "#e31e24"
  },
  {
    id: 3,
    name: "ZERO SUGAR",
    tagline: "Bold Refreshment",
    image: "https://pngimg.com/d/coca_cola_PNG2.png",
    splash: "https://static.vecteezy.com/system/resources/previews/027/292/348/original/cola-soda-splash-on-transparent-background-png.png",
    themeColor: "#1a1a1a"
  }
];

const ProductsSection: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const rippleRef = useRef<HTMLDivElement>(null);

  const nextProduct = () => setActiveIndex((prev) => (prev + 1) % PRODUCTS.length);
  const prevProduct = () => setActiveIndex((prev) => (prev - 1 + PRODUCTS.length) % PRODUCTS.length);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // Background ripple animation
      gsap.to('.ripple-circle', {
        scale: 1.15,
        opacity: 0.3,
        stagger: 0.2,
        repeat: -1,
        yoyo: true,
        duration: 3,
        ease: 'sine.inOut'
      });

      // Heading animation
      gsap.from('.products-heading', {
        x: -100,
        opacity: 0,
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 70%',
          toggleActions: 'play none none none'
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  useLayoutEffect(() => {
    const tl = gsap.timeline();
    tl.fromTo('.active-product-img', 
      { scale: 0.6, opacity: 0, y: 50 },
      { scale: 1, opacity: 1, y: 0, duration: 0.8, ease: 'back.out(1.7)' }
    );
    tl.fromTo('.product-info-text', 
      { opacity: 0, x: -30 },
      { opacity: 1, x: 0, duration: 0.6 },
      '-=0.4'
    );
  }, [activeIndex]);

  const activeProduct = PRODUCTS[activeIndex];

  return (
    <section 
      ref={sectionRef}
      className="relative w-full h-screen bg-[#b52232] overflow-hidden flex flex-col justify-center items-center z-30 -mt-1"
    >
      {/* BACKGROUND DECORATION */}
      <div ref={rippleRef} className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-30">
        {[...Array(6)].map((_, i) => (
          <div 
            key={i}
            className="ripple-circle absolute rounded-full border border-white/20"
            style={{ width: `${(i + 1) * 350}px`, height: `${(i + 1) * 350}px` }}
          />
        ))}
      </div>

      {/* OVERSIZED HEADING */}
      <div className="absolute top-[10%] left-10 md:left-24 z-10">
        <h2 className="products-heading font-bebas text-7xl md:text-[11vw] text-white/5 leading-none tracking-tighter select-none -webkit-text-stroke-[1px] -webkit-text-stroke-white/20 uppercase">
          OUR PRODUCTS
        </h2>
      </div>

      {/* MAIN CONTAINER */}
      <div ref={containerRef} className="relative w-full max-w-7xl h-full flex items-center justify-center px-10">
        
        {/* PRODUCT DETAILS */}
        <div className="product-info-text absolute left-10 md:left-24 top-1/2 -translate-y-1/2 z-30 flex flex-col items-start text-white max-w-lg">
          <div className="relative mb-6">
             <span className="font-script text-3xl md:text-5xl lowercase mb-2 block text-white/90">
               {activeProduct.tagline}
             </span>
             <div className="absolute -right-20 top-0 w-24 h-12 pointer-events-none hidden lg:block">
                <svg viewBox="0 0 100 50" className="w-full h-full stroke-white/40 fill-none stroke-2">
                   <path d="M10,40 Q50,10 90,20 M80,10 L90,20 L80,30" />
                </svg>
             </div>
          </div>
          <h3 className="font-bebas text-6xl md:text-[8vw] mb-12 tracking-wider leading-none">
            {activeProduct.name}
          </h3>
          <button className="px-14 py-5 bg-[#fdfcf8] text-[#b52232] font-bebas text-3xl tracking-widest hover:scale-110 transition-transform shadow-2xl rounded-sm">
            VIEW PRODUCT
          </button>
        </div>

        {/* CENTRAL SPOTLIGHT */}
        <div className="relative flex items-center justify-center z-20 w-full h-full md:ml-[25%]">
          <div className="absolute w-[350px] h-[350px] md:w-[650px] md:h-[650px] bg-white rounded-full opacity-10 blur-[120px]"></div>
          <div className="absolute w-[280px] h-[280px] md:w-[500px] md:h-[500px] bg-[#fdfcf8] rounded-full flex items-center justify-center overflow-visible shadow-2xl">
            <img 
              src={activeProduct.splash} 
              className="absolute w-[160%] h-[160%] object-contain pointer-events-none opacity-40 contrast-125" 
              alt="splash"
            />
            <div className="relative h-[115%] w-full flex items-center justify-center active-product-img">
              <img 
                src={activeProduct.image} 
                alt={activeProduct.name} 
                className="h-full object-contain drop-shadow-[0_50px_80px_rgba(0,0,0,0.6)] z-10" 
              />
            </div>
          </div>
        </div>

        {/* NAVIGATION */}
        <div className="absolute inset-x-0 bottom-10 md:top-1/2 md:-translate-y-1/2 flex justify-between px-10 md:px-20 z-40 pointer-events-none">
          <button 
            onClick={prevProduct} 
            className="pointer-events-auto w-16 h-16 rounded-full border-2 border-white/40 flex items-center justify-center text-white text-3xl hover:bg-white hover:text-[#b52232] transition-all shadow-xl"
          >
            ←
          </button>
          <button 
            onClick={nextProduct} 
            className="pointer-events-auto w-16 h-16 rounded-full border-2 border-white/40 flex items-center justify-center text-white text-3xl hover:bg-white hover:text-[#b52232] transition-all shadow-xl"
          >
            →
          </button>
        </div>
      </div>

      {/* SLIDE INDICATOR */}
      <div className="absolute top-12 right-12 z-10 flex items-baseline gap-3 text-white/30 font-bebas text-4xl">
        <span className="text-white text-6xl">{activeIndex + 1}</span>
        <span>/</span>
        <span>{PRODUCTS.length}</span>
      </div>
    </section>
  );
};

export default ProductsSection;
